(() => {



"use strict";



// content.js — ChatGPT Handoff Auto-Wake (Versão 2.7.0 - Blindada e Sem Saltos)



// Foco total: Confiabilidade, Zero Repetição, Zero Rolagem Involuntária







const STATIC_TRIGGER_PROMPT = "[AUTO_WAKE] @Alita Novo evento no Handoff recebido. Por favor, execute a ferramenta ler_fila para processar.";



const POLL_INTERVAL_MS = 6000;



const COOLDOWN_MS = 15000;







let pollTimer = null;



let isProcessing = false;



let seenIds = new Set();



let attemptedIds = new Set();



let deliveryWarningShown = false;



let lastDispatchedId = null;



let lastDispatchedTime = 0;







function isContextValid() {



  return typeof chrome !== "undefined" && Boolean(chrome?.runtime?.id);



}











const DIAGNOSTIC_VERSION = "2.9.0.3";



function reportStage(stage, detail = {}) {



  if (!isContextValid()) return;



  try {



    chrome.storage.local.set({wake_diagnostic: {



      version: DIAGNOSTIC_VERSION, at: new Date().toISOString(), stage, ...detail



    }}, () => { void chrome.runtime.lastError; });



  } catch (_) { /* Invalidated contexts cannot persist diagnostics. */ }



}



function extensionCall(start, timeoutMs = 20000) {



  return new Promise((resolve, reject) => {



    const timer = setTimeout(() => reject(new Error("CALL_TIMEOUT")), timeoutMs);



    try {



      start(result => {



        clearTimeout(timer);



        if (!isContextValid()) return reject(new Error("CONTEXT_INVALID"));



        if (chrome.runtime.lastError) return reject(new Error("RUNTIME_ERROR"));



        resolve(result);



      });



    } catch (_) {



      clearTimeout(timer);



      reject(new Error("CALL_FAILED"));



    }



  });



}







function eligibleWakeElement(el) {
  if (!el || !el.isConnected || el.disabled || el.getAttribute("aria-disabled") === "true" || el.getAttribute("aria-hidden") === "true" || !el.getClientRects().length) return false;
  const style = getComputedStyle(el);
  return style.display !== "none" && style.visibility !== "hidden" && style.visibility !== "collapse";
}
function wakeComposer(el) { return el?.closest('form, [data-testid="composer-container"]') || null; }
function findInput() {
  const candidates = Array.from(document.querySelectorAll('form textarea, form [contenteditable="true"], [data-testid="composer-container"] textarea, [data-testid="composer-container"] [contenteditable="true"]')).filter(eligibleWakeElement);
  return candidates.length === 1 && wakeComposer(candidates[0]) ? candidates[0] : null;
}
function findSendButton(inputEl) {
  const container = wakeComposer(inputEl);
  if (!container) return null;
  const selectors = [
    'button[data-testid="send-button"]',
    'button[data-testid="composer-submit-button"]',
    'button#composer-submit-button',
    'button[aria-label*="Enviar"]',
    'button[aria-label*="Send"]'
  ];
  const matched = new Set();
  for (const sel of selectors) {
    try {
      const list = Array.from(container.querySelectorAll(sel)).filter(el => el.isConnected && el.getClientRects().length > 0);
      for (const el of list) matched.add(el);
    } catch (_) {}
  }
  const candidateButtons = Array.from(matched);
  // Requisito P1-03: Exatamente 1 botao elegivel no compositor. Se houver desambiguacao ou 0, falha fechado.
  return candidateButtons.length === 1 ? candidateButtons[0] : null;
}

function isButtonReady(btn) {
  if (!btn || !btn.isConnected) return false;
  if (btn.disabled) return false;
  if (btn.getAttribute?.("aria-disabled") === "true") return false;
  return true;
}

function triggerFullClick(btn) {
  if (!btn) return false;
  try {
    const rect = btn.getBoundingClientRect();
    const cx = rect.left + rect.width / 2;
    const cy = rect.top + rect.height / 2;
    const evtOpts = {
      bubbles: true,
      cancelable: true,
      view: window,
      clientX: cx,
      clientY: cy,
      pointerId: 1,
      isPrimary: true,
      button: 0,
      buttons: 1
    };
    btn.dispatchEvent(new PointerEvent("pointerdown", evtOpts));
    btn.dispatchEvent(new MouseEvent("mousedown", evtOpts));
    btn.dispatchEvent(new PointerEvent("pointerup", evtOpts));
    btn.dispatchEvent(new MouseEvent("mouseup", evtOpts));
    btn.click();
    return true;
  } catch (_) {
    // P1-B: Falha apos inicio gera erro limpo sem repeticao de acao
    return false;
  }
}
async function pilotBindingValid() {
  const response = await extensionCall(done => chrome.runtime.sendMessage({action: "PILOT_BINDING_CHECK", url: window.location.href}, done));
  return response?.ok === true;
}

function hasSubmittedPrompt(promptText) {



  if (!promptText || typeof promptText !== "string") return false;



  const idMatch = promptText.match(/\bID:\s*([0-9a-fA-F-]{36})\b/);



  const targetId = idMatch ? idMatch[1] : null;



  const attMatch = promptText.match(/\|\s*Tentativa:\s*(\d+)/);



  const targetAtt = attMatch ? attMatch[1] : null;







  const normPrompt = promptText.replace(/\s+/g, " ").trim();







  // 1. Busca ampla por containers de mensagens do ChatGPT



  const candidates = document.querySelectorAll(



    'main [data-message-author-role="user"], main article, main [data-testid*="turn"], main [data-message-id], main div[class*="conversation-turn"], [data-message-author-role="user"], [data-testid*="user"], article[data-testid*="conversation-turn"]'



  );







  for (const el of candidates) {
    if (el.closest('form') || el.id === 'prompt-textarea' || el.querySelector?.('#prompt-textarea')) {
      continue;
    }

    const rawText = el.innerText || el.textContent || "";

    const normText = rawText.replace(/\s+/g, " ").trim();

    // 1. Substring completa do prompt normalizado
    if (normText === normPrompt || normText.includes(normPrompt)) {
      return true;
    }

    // 2. Coincidência estrita por marcadores canônicos de unicidade:
    if (targetId && normText.includes("[AUTO_WAKE]") && normText.includes(targetId)) {
      if (!targetAtt || normText.includes("Tentativa: " + targetAtt)) {
        return true;
      }
    }
  }

  // 2. Fallback direto no elemento main caso os seletores mudem (somente se o texto JA SAIU do editor)
  const currentInput = findInput();
  const stillInEditor = currentInput && targetId && inputText(currentInput).includes(targetId);
  const mainEl = document.querySelector('main');

  if (!stillInEditor && mainEl && targetId) {
    const mainText = mainEl.innerText || mainEl.textContent || "";
    if (mainText.includes("[AUTO_WAKE]") && mainText.includes(targetId)) {
      if (!targetAtt || mainText.includes("Tentativa: " + targetAtt)) {
        return true;
      }
    }
  }

  return false;
}

function inputText(el) {
  if (!el) return "";
  return el.tagName && el.tagName.toLowerCase() === "textarea"
    ? (el.value || "")
    : (el.innerText || el.textContent || "");
}

function hasInjectedText(el, promptText) {
  if (!el || !promptText) return false;
  const normCurrent = inputText(el).replace(/\s+/g, " ").trim();
  const normTarget = promptText.replace(/\s+/g, " ").trim();
  if (!normCurrent) return false;
  if (normCurrent === normTarget) return true;
  const idMatch = promptText.match(/\bID:\s*([0-9a-fA-F-]{36})\b/);
  if (idMatch && normCurrent.includes(idMatch[1])) {
    return normCurrent.length >= Math.min(normTarget.length * 0.8, normTarget.length - 20);
  }
  return normCurrent.length >= normTarget.length * 0.9 && normCurrent.slice(0, 60) === normTarget.slice(0, 60);
}

function isStreaming() {
  return Boolean(
    document.querySelector('button[data-testid="stop-button"]') ||
    document.querySelector('[data-testid="stop-button"]') ||
    document.querySelector('button[aria-label*="Stop" i]') ||
    document.querySelector('button[aria-label*="Parar" i]') ||
    document.querySelector('.result-streaming') ||
    document.querySelector('.streaming-animation')
  );
}







async function injectAndSubmit(promptText) {



  // Serializar abas da mesma origem. Sem Locks API, não enviar automaticamente.



  if (!navigator.locks) { reportStage("LOCKS_UNAVAILABLE"); return {status: "BLOCKED_PRE_RESERVATION", reason: "LOCKS_UNAVAILABLE"}; }



  return navigator.locks.request("chatgpt-handoff-submit-v1", async () => {



    return injectAndSubmitLocked(promptText);



  });



}







async function reserveAttempt(promptText) {



  const match = promptText.match(/\bID: ([0-9a-fA-F-]{36})\b/);



  if (!match) return false;



  const id = match[1];



  const attMatch = promptText.match(/\|\s*Tentativa:\s*(\d+)/);



  const att = attMatch ? attMatch[1] : "1";



  const reservationKey = `${id}#${att}`;



  const isRearmAttempt = Number(att) > 1;



  return new Promise(resolve => {



    chrome.storage.local.get(["wake_attempted_ids"], stored => {



      if (chrome.runtime.lastError) return resolve(false);



      const ids = Array.isArray(stored?.wake_attempted_ids) ? stored.wake_attempted_ids : [];



      const isBlocked = isRearmAttempt ? ids.includes(reservationKey) : (ids.includes(id) || ids.includes(reservationKey));



      if (isBlocked || ids.length >= 1000) return resolve(false);



      // Persistir ANTES do clique. Resultado incerto exige revisão, nunca reenvio automático.



      chrome.storage.local.set({wake_attempted_ids: [...ids, reservationKey, id]}, () => {



        if (chrome.runtime.lastError) return resolve(false);



        attemptedIds.add(id);



        attemptedIds.add(reservationKey);



        resolve(true);



      });



    });



  });



}







function wakeUserTurns() {
  return Array.from(document.querySelectorAll('[data-message-author-role="user"]'));
}
function wakeReceiptMatches(node, promptText) {
  const nodeText = (node.innerText || node.textContent || "").replace(/\s+/g, " ").trim();
  const targetText = promptText.replace(/\s+/g, " ").trim();
  if (nodeText === targetText) return true;
  // P1-D Fechado: Validacao canonica delimitada com igualdade estrita de ID e numero de tentativa (sem colisao substring)
  const idMatch = promptText.match(/\bID:\s*([0-9a-fA-F-]{36})\b/);
  const attMatch = promptText.match(/\|\s*Tentativa:\s*(\d+)\b/);
  if (idMatch && attMatch) {
    const requiredId = idMatch[1];
    const expectedAttemptNum = attMatch[1];
    if (nodeText.includes("[AUTO_WAKE]") && nodeText.includes(requiredId)) {
      const nodeAttMatch = nodeText.match(/\|\s*Tentativa:\s*(\d+)\b/);
      if (nodeAttMatch && nodeAttMatch[1] === expectedAttemptNum) {
        return true;
      }
    }
  }
  return false;
}
async function injectAndSubmitLocked(promptText) {
  const blocked = reason => ({status: "BLOCKED_PRE_RESERVATION", reason});
  const uncertain = reason => ({status: "RESERVED_UNCERTAIN", reason});
  const normalize = text => text.replace(/\s+/g, " ").trim();
  const initialUrl = window.location.href;
  if (!(await pilotBindingValid())) return blocked("NAO_CONFIGURADO_OR_WRONG_TARGET");
  // A pre-existing matching turn is not evidence of a new submission.
  const priorTurns = new Set(wakeUserTurns());
  if (wakeUserTurns().some(node => wakeReceiptMatches(node, promptText))) return uncertain("ALREADY_IN_DOM");
  const inputEl = findInput();
  if (!inputEl) return blocked("EDITOR_NOT_UNIQUE");
  const draft = inputText(inputEl).trim();
  if (draft && normalize(draft) !== normalize(promptText)) return blocked("DRAFT_PRESENT");
  // Inserir texto caso o campo esteja vazio ou precise ser reposto
  if (!draft || !hasInjectedText(inputEl, promptText)) {
    // Do not force focus in the pilot.

    if (inputEl.tagName.toLowerCase() === "textarea") {
      const tracker = inputEl._valueTracker;
      if (tracker) tracker.setValue("");
      const setter = Object.getOwnPropertyDescriptor(HTMLTextAreaElement.prototype, "value")?.set;
      if (setter) setter.call(inputEl, promptText);
      else inputEl.value = promptText;
      inputEl.dispatchEvent(new Event("input", { bubbles: true }));
      inputEl.dispatchEvent(new Event("change", { bubbles: true }));
    } else {
      // Metodo 1 (Padrao Ouro ProseMirror em segundo plano): InputEvent 'beforeinput' + 'input'
      try {
        inputEl.dispatchEvent(new InputEvent("beforeinput", {
          bubbles: true, cancelable: true, composed: true, inputType: "insertText", data: promptText
        }));
        inputEl.dispatchEvent(new InputEvent("input", {
          bubbles: true, cancelable: true, composed: true, inputType: "insertText", data: promptText
        }));
      } catch (_) {}

      // Metodo 2: ClipboardEvent 'paste' com DataTransfer (se Metodo 1 nao inseriu)
      if (!hasInjectedText(inputEl, promptText)) {
        try {
          const dt = new DataTransfer();
          dt.setData("text/plain", promptText);
          const pasteEv = new ClipboardEvent("paste", {
            clipboardData: dt,
            bubbles: true,
            cancelable: true,
            composed: true
          });
          inputEl.dispatchEvent(pasteEv);
        } catch (_) {}
      }

      // Metodo 3: execCommand insertText (SOMENTE se Metodos 1 e 2 nao inseriram o texto)
      if (!hasInjectedText(inputEl, promptText)) {
        try {
          const sel = window.getSelection();
          if (sel) {
            const range = document.createRange();
            range.selectNodeContents(inputEl);
            sel.removeAllRanges();
            sel.addRange(range);
          }
          document.execCommand("selectAll", false, null);
          document.execCommand("insertText", false, promptText);
        } catch (_) {}
      }

      // Metodo 4: innerHTML + beforeinput (ultimo recurso se o campo continuar vazio)
      if (!hasInjectedText(inputEl, promptText)) {
        inputEl.innerHTML = `<p>${promptText.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;")}</p>`;
        try {
          inputEl.dispatchEvent(new InputEvent("beforeinput", {
            bubbles: true, cancelable: true, inputType: "insertText", data: promptText
          }));
          inputEl.dispatchEvent(new InputEvent("input", {
            bubbles: true, cancelable: true, composed: true, inputType: "insertText", data: promptText
          }));
        } catch (_) {}
      }

      // Notificacao de eventos ao React
      try {
        inputEl.dispatchEvent(new Event("input", { bubbles: true, cancelable: true }));
        inputEl.dispatchEvent(new Event("change", { bubbles: true, cancelable: true }));
      } catch (_) {}
    }
  }


  if (!hasInjectedText(inputEl, promptText) && normalize(inputText(inputEl)) !== normalize(promptText)) return blocked("EDITOR_INSERT_FAILED");
  let reservationConfirmed = false;
  try { reservationConfirmed = (await reserveAttempt(promptText)) === true; }
  catch (_) { return uncertain("ATTEMPT_RESERVATION_ERROR"); }
  // An existing reservation or an ambiguous storage write must never rearm.
  if (!reservationConfirmed) return uncertain("ATTEMPT_RESERVATION_BLOCKED");
  reportStage("CLICK_RESERVED");
  let btn = null;
  const btnDeadline = Date.now() + 4000;
  while (Date.now() < btnDeadline) {
    btn = findSendButton(inputEl);
    if (isButtonReady(btn)) break;
    await new Promise(r => setTimeout(r, 100));
  }
  if (window.location.href !== initialUrl || (!hasInjectedText(inputEl, promptText) && normalize(inputText(inputEl)) !== normalize(promptText))) return uncertain("CONTEXT_CHANGED");
  if (!(await pilotBindingValid())) return uncertain("BINDING_CHANGED");
  reportStage("SUBMISSION_ATTEMPTED");
  if (!isButtonReady(btn)) {
    // P1-A: Ambiguidade ou botao desabilitado/ausente falha fechado imediatamente; zero despacho por Enter
    return uncertain("BUTTON_UNAVAILABLE_OR_AMBIGUOUS");
  }
  const submissionDispatched = triggerFullClick(btn);
  if (!submissionDispatched) return uncertain("SUBMISSION_DISPATCH_FAILED");
  const deadline = Date.now() + 15000;
  while (true) {
    if (window.location.href !== initialUrl) return uncertain("CONTEXT_CHANGED");
    const currentTurns = wakeUserTurns();
    if ([...priorTurns].some(node => !currentTurns.includes(node))) return uncertain("DOM_REPLACED");
    const receipt = currentTurns.find(node => !priorTurns.has(node) && wakeReceiptMatches(node, promptText));
    if (receipt) return {status: "CONFIRMED", reason: "NEW_MATCHING_USER_TURN"};

    if (Date.now() >= deadline) return uncertain("RECEIPT_UNCERTAIN");
    await new Promise(r => setTimeout(r, 200));
  }
}

// Wake-only pilot: no assistant DOM extraction, reply restoration, timer or SEND_REPLY.
async function performPoll() {



  if (!isContextValid() || isProcessing) return;



  isProcessing = true;



  try {



    if (Date.now() - lastDispatchedTime < COOLDOWN_MS) return;



    if (isStreaming()) { reportStage("CHAT_BUSY"); return; }



    const token = null; // Local existing endpoint; no bundled credential/config.js.



    if (!(await pilotBindingValid())) { reportStage("NAO_CONFIGURADO_OR_WRONG_TARGET"); return; }



    reportStage("READING_STATE");



    const stored = await extensionCall(done => chrome.storage.local.get(



      ["seen_ids", "last_dispatched_id", "wake_attempted_ids", "wake_rearm_ids", "rearm_ids", "wake_attempts"], done));







    // Preserve all durable reservations; incoming rearm hints cannot clear uncertainty.
    seenIds = new Set(Array.isArray(stored?.seen_ids) ? stored.seen_ids : []);
    attemptedIds = new Set(Array.isArray(stored?.wake_attempted_ids) ? stored.wake_attempted_ids : []);
    lastDispatchedId = stored?.last_dispatched_id || null;

    reportStage("FETCHING");



    const response = await extensionCall(done => chrome.runtime.sendMessage(



      {action: "FETCH_GATEWAY", token}, done));



    if (!response || !response.ok || response.data?.ok === false) {



      reportStage("FETCH_FAILED", {status: Number(response?.status) || 0});



      return;



    }



        const msgs = response.data?.mensagens || response.data?.messages || [];







        // DETECÇÃO E GRAVAÇÃO DE REARMES EMITIDOS PELO SUPERVISOR NO TRANSPORTE HANDOFF:



        // Automatic rearm is deliberately disabled in this isolated candidate.
        // Stored and transport hints are not authority to delete a reservation.
        const pending = msgs.filter(m => {
  const state = {seenIds, attemptedIds, lastDispatchedId};

  if (!m || typeof m.id !== 'string' || !m.id) return false;
  if (state.seenIds?.has(m.id) || state.attemptedIds?.has(m.id) || m.id === state.lastDispatchedId) return false;
  if (m.created_at) {
    const msgTs = new Date(m.created_at).getTime();
    if (!isNaN(msgTs) && (Date.now() - msgTs > 60 * 60 * 1000)) return false;
  }
  if (typeof m.remetente !== 'string') return false;
  const aliases = {
    ALITA:'CHATGPT', CHATGPT:'CHATGPT', 'ALITA (CHATGPT)':'CHATGPT', 'CHATGPT (ALITA)':'CHATGPT',
    ATLAS:'CODEX', CODEX:'CODEX', 'ATLAS (CODEX)':'CODEX', 'CODEX (ATLAS)':'CODEX',
    ISAAC:'ANTIGRAVITY', ANTIGRAVITY:'ANTIGRAVITY', 'ISAAC (ANTIGRAVITY)':'ANTIGRAVITY', 'ANTIGRAVITY (ISAAC)':'ANTIGRAVITY',
    ANTIGRAVITY_PC1:'ANTIGRAVITY', ANTIGRAVITY_PC2:'ANTIGRAVITY', 'ANTIGRAVITY (PC1)':'ANTIGRAVITY', 'ANTIGRAVITY (PC2)':'ANTIGRAVITY',
    NIKOLA:'ANTIGRAVITY', 'NIKOLA (PC2)':'ANTIGRAVITY', 'NIKOLA (ANTIGRAVITY)':'ANTIGRAVITY',
    'ISAAC (PC1)':'ANTIGRAVITY', 'ISAAC PC1':'ANTIGRAVITY', 'NIKOLA PC2':'ANTIGRAVITY',
    IRIS:'IRIS', 'ÍRIS':'IRIS', SUPERVISOR:'SUPERVISOR', GATEWAY:'GATEWAY'
  };
  const normalize = value => aliases[value.trim().replace(/[ \t]+/g,' ').toUpperCase()] || value.trim().toUpperCase();
  const sender = normalize(m.remetente);
  if (!['CODEX','ANTIGRAVITY','IRIS','SUPERVISOR','GATEWAY','ATLAS','ISAAC','NIKOLA'].includes(sender)) return false;
  const status = typeof m.status === 'string' ? m.status.trim().toUpperCase() : '';
  const queue = typeof m.target_queue === 'string' ? m.target_queue.trim().toUpperCase() : '';
  if (status === 'COMPLETED' || status === 'PROCESSED' || status === 'CANCELLED') return false;
  const isWaiting = !m.status ||
    status === 'WAITING_ALITA' || status === 'WAITING_CHATGPT' ||
    queue === 'WAITING_ALITA' || queue === 'WAITING_CHATGPT' ||
    status === 'PENDING' || status === 'PROCESSING';
  return isWaiting;
});

        reportStage("FILTERED", {received: msgs.length, eligible: pending.length});



        if (pending.length === 0) {



          scheduleNext(POLL_INTERVAL_MS);



          return;



        }







        const target = pending[0];



        const targetId = target.id;



        const targetTs = target.created_at || "";







        // TRAVA IMEDIATA: Bloqueia o ID antes de qualquer ação



        reportStage("DELIVERY_STARTED", {id: targetId});



        // Formatação segura de timestamp BRT com Intl.DateTimeFormat



        let timeBrt = "INDISPONIVEL";



        if (targetTs && typeof targetTs === "string") {



          try {



            const parsedDate = new Date(targetTs);



            if (!isNaN(parsedDate.getTime())) {



              const formatter = new Intl.DateTimeFormat("pt-BR", {



                timeZone: "America/Sao_Paulo",



                day: "2-digit",



                month: "2-digit",



                year: "numeric",



                hour: "2-digit",



                minute: "2-digit",



                second: "2-digit",



                hour12: false



              });



              timeBrt = formatter.format(parsedDate) + " BRT";



            }



          } catch (e) {



            timeBrt = "INDISPONIVEL";



          }



        }







        // Sanitização de remetente com allowlist restrita contra prompt injection



        const ALLOWED_SENDERS = ["ATLAS", "CODEX", "ISAAC", "NIKOLA", "ANTIGRAVITY", "SUPERVISOR", "GATEWAY", "IRIS", "ÍRIS"];



        const rawSender = (target.remetente || "").toString().trim().toUpperCase();



        const formatterAliases = {
          "ATLAS": "ATLAS", "CODEX": "ATLAS", "ATLAS (CODEX)": "ATLAS", "CODEX (ATLAS)": "ATLAS",
          "ISAAC": "ISAAC", "ANTIGRAVITY": "ISAAC", "ISAAC (ANTIGRAVITY)": "ISAAC", "ANTIGRAVITY (ISAAC)": "ISAAC", "ANTIGRAVITY_PC1": "ISAAC",
          "NIKOLA": "NIKOLA", "NIKOLA (PC2)": "NIKOLA", "NIKOLA (ANTIGRAVITY)": "NIKOLA", "ANTIGRAVITY_PC2": "NIKOLA",
          "ALITA": "ALITA", "CHATGPT": "ALITA"
        };
        const normalizedSender = formatterAliases[rawSender.replace(/[ \t]+/g, " ")] || rawSender;
        const safeSender = ALLOWED_SENDERS.includes(normalizedSender) ? normalizedSender : "DESCONHECIDO";







        // Truncamento seguro de UUID / correlação



        const safeTargetId = (typeof targetId === "string" && /^[0-9a-fA-F-]{8,36}$/.test(targetId))



          ? targetId.slice(0, 36)



          : "INVALIDO";







        const rawCorr = (target.correlation_id || "").toString().replace(/[^a-zA-Z0-9_-]/g, "");



        const corrPart = rawCorr ? ` | Corr: ${rawCorr.slice(0, 36)}` : "";







        const storedAttempts = (stored && typeof stored.wake_attempts === "object" && stored.wake_attempts !== null)



          ? stored.wake_attempts



          : {};



        const parsedAttempt = Number(target.attempt || target.tentativa || target.retry_count || storedAttempts[targetId] || 1);



        const currentAttempt = (!isNaN(parsedAttempt) && parsedAttempt > 0) ? parsedAttempt : 1;



        const attemptPart = ` | Tentativa: ${currentAttempt}`;







        let promptText = `[AUTO_WAKE] ${timeBrt} | ${safeSender} -> ALITA | ID: ${safeTargetId}${corrPart}${attemptPart}.\n\n`;
        if (target.payload && typeof target.payload === "string" && target.payload.trim().length > 0) {
          if (target.payload.trim().length > 1500) {
            promptText += `@Alita Mensagem técnica recebida de ${safeSender} no Handoff (${target.payload.trim().length} caracteres). Por favor, execute a ferramenta ler_fila para processar o payload completo nos bastidores.`;
          } else {
            promptText += target.payload.trim();
          }
        } else {
          promptText += `@Alita Novo evento no Handoff recebido. Por favor, execute a ferramenta ler_fila para processar.`;
        }







        try {
          const baselineSnapshot = []; // Wake-only: no assistant DOM access.
          const resolvedTaskId = target.task_id || target.correlation_id || targetId;

          const submitted = await injectAndSubmit(promptText);



          if (submitted?.status !== "CONFIRMED") {
            reportStage(submitted?.status || "RESERVED_UNCERTAIN", {id: targetId, attempt: currentAttempt, reason: submitted?.reason || "INVALID_RESULT"});
            return;
          }

          reportStage("DELIVERY_CONFIRMED", {id: targetId, attempt: currentAttempt});
          seenIds.add(targetId);



          lastDispatchedId = targetId;



          lastDispatchedTime = Date.now();



          storedAttempts[targetId] = currentAttempt + 1;



          chrome.storage.local.set({



            seen_ids: Array.from(seenIds).slice(-150),



            last_dispatched_id: targetId,



            last_dispatched_at: lastDispatchedTime,



            wake_attempts: storedAttempts



          });



        } catch (err) {



          reportStage("DELIVERY_ERROR");



          console.warn("[AUTO_WAKE] Falha na entrega; consultar wake_diagnostic.");



        }







  } catch (error) {



    const known = ["CALL_TIMEOUT", "CONTEXT_INVALID", "RUNTIME_ERROR", "CALL_FAILED"];



    reportStage("POLL_ERROR", {reason: known.includes(error?.message) ? error.message : "UNEXPECTED"});



  } finally {



    isProcessing = false;



    scheduleNext(POLL_INTERVAL_MS);



  }



}







function scheduleNext(delayMs) {



  if (!isContextValid()) return;



  if (pollTimer) clearTimeout(pollTimer);



  pollTimer = setTimeout(performPoll, delayMs);



}







// Iniciar polling apenas nas abas do ChatGPT



if (window.location.hostname.includes("chatgpt.com") || window.location.hostname.includes("chat.openai.com")) {



  performPoll();



}








// Focus/visibility may poll, but never submit directly or clear a reservation.
window.addEventListener("focus", () => { void performPoll(); });
document.addEventListener("visibilitychange", () => {
  if (document.visibilityState === "visible") void performPoll();
});
// The 400ms submission sentinel is removed; the existing poll owns submission.
})();
