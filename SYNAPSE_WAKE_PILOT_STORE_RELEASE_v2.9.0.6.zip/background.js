// background.js — ChatGPT Handoff Wake Assistant (Versao 2.9.0.5 Blindada)
// Consulta e retorno local-first resiliente a fila do Handoff (127.0.0.1:8080)

const LOCAL_GATEWAY_URL = "http://127.0.0.1:8080/api/handoff/poll_alita";
const LOCAL_MCP_FALLBACK_URL = "http://127.0.0.1:8001/api/wake_alita";

chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  // Binding is checked strictly against Chrome sender.tab and explicit stored tabId.
  // P1-C Remediado: Sem auto-revinculo implicito por silencio; zero mutacao antes de autorizacao.
  if (request.action === "PILOT_BINDING_CHECK" || request.action === "FETCH_GATEWAY") {
    chrome.storage.local.get(["pilot_binding", "wake_attempted_ids"], stored => {
      const cfg = stored?.pilot_binding;
      const senderTabId = sender.tab?.id;
      const senderUrl = sender.tab?.url;

      const valid = cfg?.enabled === true && cfg.reservationsReviewed === true &&
        Array.isArray(stored?.wake_attempted_ids) &&
        sender.id === chrome.runtime.id && sender.frameId === 0 &&
        Number.isInteger(senderTabId) && senderTabId === cfg.tabId &&
        sender.url === cfg.chatUrl && senderUrl === cfg.chatUrl &&
        /^https:\/\/(chatgpt\.com|chat\.openai\.com)\/c\/[a-zA-Z0-9-]+$/.test(cfg.chatUrl) &&
        (!request.url || request.url === cfg.chatUrl);

      if (!valid || chrome.runtime.lastError) {
        sendResponse({ ok: false, error: "NAO_CONFIGURADO_OR_WRONG_TARGET" });
        return;
      }

      if (request.action === "PILOT_BINDING_CHECK") {
        sendResponse({ ok: true });
        return;
      }
      fetchPilotMessages(sendResponse);
    });
    return true;
  }
});

function fetchPilotMessages(sendResponse) {
  async function fetchMessages(url) {
    const controller = new AbortController();
    const timeout = setTimeout(() => controller.abort(), 6000);
    try {
      const res = await fetch(url, { signal: controller.signal });
      if (!res.ok) throw new Error("HTTP_" + res.status);
      const data = await res.json();
      return { messages: data.messages || [] };
    } finally {
      clearTimeout(timeout);
    }
  }
  (async () => {
    let data;
    try {
      data = await fetchMessages(LOCAL_GATEWAY_URL);
    } catch (_) {
      try {
        data = await fetchMessages(LOCAL_MCP_FALLBACK_URL);
      } catch (_) {
        sendResponse({ ok: false, error: "GATEWAY_AND_FALLBACK_UNAVAILABLE" });
        return;
      }
    }
    sendResponse({ ok: true, data });
  })();
}
