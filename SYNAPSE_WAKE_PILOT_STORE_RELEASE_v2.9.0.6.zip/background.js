function normalizeChatUrl(u) {
  if (!u || typeof u !== "string") return "";
  try {
    const parsed = new URL(u.trim());
    let path = parsed.pathname.replace(/\/+$/, "");
    return `${parsed.origin}${path}`;
  } catch (e) {
    return u.trim().replace(/\/+$/, "");
  }
}

// background.js — ChatGPT Handoff Wake Assistant (Versao 2.8.0 Bidirecional Blindada)
// Consulta e retorno local-first resiliente a fila do Handoff (127.0.0.1:8080)

const LOCAL_GATEWAY_URL = "http://127.0.0.1:8080/api/handoff/poll_alita";
const LOCAL_MCP_FALLBACK_URL = "http://127.0.0.1:8001/api/wake_alita";

chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  // Binding is checked against Chrome sender.tab, never a content-supplied tab ID.
  if (request.action === "PILOT_BINDING_CHECK" || request.action === "FETCH_GATEWAY") {
    chrome.storage.local.get(["pilot_binding", "wake_attempted_ids"], stored => {
      const cfg = stored.pilot_binding;
      // Auto-revinculo resiliente: se a URL da conversa bate com a autorizada, atualiza o tabId para sobreviver a reinicios
      if (cfg?.enabled === true && normalizeChatUrl(sender.tab?.url) === normalizeChatUrl(cfg.chatUrl) && sender.tab?.id && sender.tab.id !== cfg.tabId) {
        cfg.tabId = sender.tab.id;
        chrome.storage.local.set({ pilot_binding: cfg });
      }
      const valid = cfg?.enabled === true && cfg.reservationsReviewed === true &&
        Array.isArray(stored.wake_attempted_ids) &&
        sender.id === chrome.runtime.id && sender.frameId === 0 &&
        Number.isInteger(sender.tab?.id) && (sender.tab.id === cfg.tabId || sender.normalizeChatUrl(tab.url) === normalizeChatUrl(cfg.chatUrl)) &&
        normalizeChatUrl(sender.url) === normalizeChatUrl(cfg.chatUrl) && sender.normalizeChatUrl(tab.url) === normalizeChatUrl(cfg.chatUrl) &&
        /^https:\/\/(chatgpt\.com|chat\.openai\.com)\/c\/[a-zA-Z0-9-]+$/.test(cfg.chatUrl) &&
        (!request.url || request.url === cfg.chatUrl);
      if (!valid || chrome.runtime.lastError) { sendResponse({ok:false,error:"NAO_CONFIGURADO_OR_WRONG_TARGET"}); return; }
      if (request.action === "PILOT_BINDING_CHECK") { sendResponse({ok:true}); return; }
      fetchPilotMessages(sendResponse);
    });
    return true;
  }
  // No SEND_REPLY action is supported by this wake-only package.
});
function fetchPilotMessages(sendResponse) {
  // 1. Busca de tarefas pendentes para o ChatGPT (Ida)

    async function fetchMessages(url) {
      const controller = new AbortController();
      const timeout = setTimeout(() => controller.abort(), 6000);
      try {
        const res = await fetch(url, { signal: controller.signal });
        if (!res.ok) throw new Error("HTTP_" + res.status);
        const data = await res.json();
        return { messages: data.messages || [] };
      } finally {
        clearTimeout(timeout);
      }
    }
    (async () => {
      let data;
      try {
        data = await fetchMessages(LOCAL_GATEWAY_URL);
      } catch (_) {
        try {
          data = await fetchMessages(LOCAL_MCP_FALLBACK_URL);
        } catch (_) {
          sendResponse({ ok: false, error: "GATEWAY_AND_FALLBACK_UNAVAILABLE" });
          return;
        }
      }
      sendResponse({ ok: true, data });
    })();

}
