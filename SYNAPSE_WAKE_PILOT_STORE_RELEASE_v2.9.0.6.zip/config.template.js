// config.template.js - Modelo de configuracao sanitizado sem tokens reais
const HANDOFF_TOKEN_LOCAL = "INSIRA_SEU_TOKEN_AQUI";
