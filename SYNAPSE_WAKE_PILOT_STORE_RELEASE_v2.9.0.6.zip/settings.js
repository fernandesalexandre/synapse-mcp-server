"use strict";
const byId = id => document.getElementById(id);

// Preenche URL ativa caso já esteja salva
chrome.storage.local.get(["pilot_binding"], stored => {
  if (stored?.pilot_binding?.chatUrl) {
    byId("url").value = stored.pilot_binding.chatUrl;
    if (stored.pilot_binding.enabled) {
      byId("status").textContent = "🟢 Vínculo ativo e protegendo a equipe nesta conversa!";
      byId("status").style.color = "#34d399";
    }
  }
});

byId("save").addEventListener("click", () => {
  const chatUrl = byId("url").value.trim();
  if (!/^https:\/\/(chatgpt\.com|chat\.openai\.com)\/c\/[a-zA-Z0-9-]+$/.test(chatUrl)) {
    byId("status").textContent = "❌ URL inválida. Cole a URL completa da conversa (ex: https://chatgpt.com/c/...)";
    byId("status").style.color = "#f87171";
    return;
  }
  if (!byId("review").checked) {
    byId("status").textContent = "❌ Por favor, marque a caixa de autorização.";
    byId("status").style.color = "#f87171";
    return;
  }

  chrome.storage.local.get(["wake_attempted_ids"], s => {
    const ids = Array.isArray(s?.wake_attempted_ids) ? s.wake_attempted_ids : [];
    chrome.storage.local.set({
      wake_attempted_ids: ids,
      pilot_binding: {
        enabled: true,
        reservationsReviewed: true,
        chatUrl: chatUrl,
        tabId: null // Auto-vincula na primeira checagem da aba correspondente
      }
    }, () => {
      if (chrome.runtime.lastError) {
        byId("status").textContent = "❌ Erro ao salvar configurações locais.";
        byId("status").style.color = "#f87171";
      } else {
        byId("status").textContent = "✅ Vínculo guardado com sucesso! Vigília ativa nesta conversa.";
        byId("status").style.color = "#34d399";
      }
    });
  });
});

byId("stop").addEventListener("click", () => {
  chrome.storage.local.set({ pilot_binding: { enabled: false } }, () => {
    byId("status").textContent = "⏹️ Vigília pausada.";
    byId("status").style.color = "#94a3b8";
  });
});
