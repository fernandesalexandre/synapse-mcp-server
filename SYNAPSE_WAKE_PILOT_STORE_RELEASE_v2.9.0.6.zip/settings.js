"use strict";
const byId=id=>document.getElementById(id);
byId("save").addEventListener("click",()=>{
 const chatUrl=byId("url").value.trim(),tabId=Number(byId("tab").value);
 if(!/^https:\/\/(chatgpt\.com|chat\.openai\.com)\/c\/[a-zA-Z0-9-]+$/.test(chatUrl)||!Number.isInteger(tabId)||tabId<0||!byId("review").checked){byId("status").textContent="NAO_CONFIGURADO";return;}
 chrome.storage.local.get(["wake_attempted_ids"],s=>{
 if(chrome.runtime.lastError||!Array.isArray(s.wake_attempted_ids)){byId("status").textContent="HOLD: reservas/identidade não demonstradas; nenhuma lista vazia será criada";return;}
 chrome.storage.local.set({pilot_binding:{enabled:true,reservationsReviewed:true,chatUrl,tabId}},()=>{byId("status").textContent=chrome.runtime.lastError?"HOLD":"Vínculo guardado; não equivale a homologação";});
 });
});
byId("stop").addEventListener("click",()=>chrome.storage.local.set({pilot_binding:{enabled:false}},()=>{byId("status").textContent="PARADO — reservas preservadas";}));
