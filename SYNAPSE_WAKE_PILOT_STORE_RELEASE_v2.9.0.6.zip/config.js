// config.js - Chave e configuracao local do assistente
const HANDOFF_TOKEN_LOCAL = "Alitawaketoken124578_004236";
